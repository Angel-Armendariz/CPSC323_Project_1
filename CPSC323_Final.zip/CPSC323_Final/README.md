# CPSC323_Project_1
* Due Date: 10/2 11:59 PM

We will be making a lexical analyzer for project 1 in python
